import subprocess, os

# Download RVC models from github
assets_folder = "./rvc_models/"
if not os.path.exists(assets_folder):
    os.makedirs(assets_folder)
files = {
    "rmvpe.pt":"https://huggingface.co/AI4future/RVC/resolve/main/rmvpe.pt",
    "hubert_base.pt":"https://huggingface.co/AI4future/RVC/resolve/main/hubert_base.pt",
}

for file, link in files.items():
    file_path = os.path.join(assets_folder, file)
    if not os.path.exists(file_path):
        try:
            subprocess.run(['wget', link, '-O', file_path], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Error downloading {file}: {e}")

# Download mdxnet models from huggingface
assets_folder = "./mdxnet_models/"
if not os.path.exists(assets_folder):
    os.makedirs(assets_folder)
files = {
    "UVR-MDX-NET-Voc_FT.onnx":"https://huggingface.co/AI4future/RVC/resolve/main/UVR-MDX-NET-Voc_FT.onnx",
    "UVR_MDXNET_KARA_2.onnx":"https://huggingface.co/AI4future/RVC/resolve/main/UVR_MDXNET_KARA_2.onnx",
    "Reverb_HQ_By_FoxJoy.onnx":"https://huggingface.co/AI4future/RVC/resolve/main/Reverb_HQ_By_FoxJoy.onnx",
}

for file, link in files.items():
    file_path = os.path.join(assets_folder, file)
    if not os.path.exists(file_path):
        try:
            subprocess.run(['wget', link, '-O', file_path], check=True)
        except subprocess.CalledProcessError as e:
            print(f"Error downloading {file}: {e}")